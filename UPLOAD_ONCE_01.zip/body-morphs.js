import { DIRECT_01 } from "./body-morphs-part-01.js";
import { DIRECT_02 } from "./body-morphs-part-02.js";
import { DIRECT_03 } from "./body-morphs-part-03.js";
import { DIRECT_04 } from "./body-morphs-part-04.js";
export const DIRECT={ ...DIRECT_01,...DIRECT_02,...DIRECT_03,...DIRECT_04 };
